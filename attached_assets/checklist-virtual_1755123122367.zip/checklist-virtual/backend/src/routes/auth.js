const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const database = require('../config/database');
const { generateToken, authenticateToken } = require('../middleware/auth');
const { sendVerificationEmail, sendPasswordResetEmail } = require('../utils/email');

const router = express.Router();

// Registro de usuário
router.post('/register', async (req, res) => {
  try {
    const { email, password, name, role } = req.body;

    // Validações básicas
    if (!email || !password || !name || !role) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }

    if (!['admin', 'coordenador', 'analista', 'tecnico'].includes(role)) {
      return res.status(400).json({ error: 'Tipo de usuário inválido' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'A senha deve ter pelo menos 6 caracteres' });
    }

    // Verificar se o email já existe
    database.getDb().get(
      'SELECT id FROM users WHERE email = ?',
      [email],
      async (err, existingUser) => {
        if (err) {
          return res.status(500).json({ error: 'Erro interno do servidor' });
        }

        if (existingUser) {
          return res.status(400).json({ error: 'Email já está em uso' });
        }

        // Hash da senha
        const hashedPassword = await bcrypt.hash(password, 10);
        const verificationToken = uuidv4();

        // Inserir usuário
        database.getDb().run(
          `INSERT INTO users (email, password, name, role, verification_token)
           VALUES (?, ?, ?, ?, ?)`,
          [email, hashedPassword, name, role, verificationToken],
          function(err) {
            if (err) {
              return res.status(500).json({ error: 'Erro ao criar usuário' });
            }

            // Enviar email de verificação (simulado)
            console.log(`Email de verificação enviado para ${email}`);
            console.log(`Token de verificação: ${verificationToken}`);

            res.status(201).json({
              message: 'Usuário criado com sucesso. Verifique seu email para ativar a conta.',
              userId: this.lastID
            });
          }
        );
      }
    );
  } catch (error) {
    console.error('Erro no registro:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Login
router.post('/login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email e senha são obrigatórios' });
    }

    database.getDb().get(
      'SELECT * FROM users WHERE email = ?',
      [email],
      async (err, user) => {
        if (err) {
          return res.status(500).json({ error: 'Erro interno do servidor' });
        }

        if (!user) {
          return res.status(401).json({ error: 'Credenciais inválidas' });
        }

        if (!user.is_verified) {
          return res.status(401).json({ error: 'Conta não verificada. Verifique seu email.' });
        }

        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
          return res.status(401).json({ error: 'Credenciais inválidas' });
        }

        const token = generateToken(user);

        res.json({
          message: 'Login realizado com sucesso',
          token,
          user: {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role
          }
        });
      }
    );
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Verificar email
router.get('/verify/:token', (req, res) => {
  const { token } = req.params;

  database.getDb().run(
    'UPDATE users SET is_verified = TRUE, verification_token = NULL WHERE verification_token = ?',
    [token],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }

      if (this.changes === 0) {
        return res.status(400).json({ error: 'Token de verificação inválido' });
      }

      res.json({ message: 'Email verificado com sucesso!' });
    }
  );
});

// Solicitar reset de senha
router.post('/forgot-password', (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({ error: 'Email é obrigatório' });
  }

  const resetToken = uuidv4();
  const resetTokenExpires = new Date(Date.now() + 3600000); // 1 hora

  database.getDb().run(
    'UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE email = ?',
    [resetToken, resetTokenExpires.toISOString(), email],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }

      if (this.changes === 0) {
        return res.status(404).json({ error: 'Email não encontrado' });
      }

      // Simular envio de email
      console.log(`Email de reset enviado para ${email}`);
      console.log(`Token de reset: ${resetToken}`);

      res.json({ message: 'Email de recuperação enviado!' });
    }
  );
});

// Reset de senha
router.post('/reset-password', async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    if (!token || !newPassword) {
      return res.status(400).json({ error: 'Token e nova senha são obrigatórios' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'A senha deve ter pelo menos 6 caracteres' });
    }

    database.getDb().get(
      'SELECT id FROM users WHERE reset_token = ? AND reset_token_expires > ?',
      [token, new Date().toISOString()],
      async (err, user) => {
        if (err) {
          return res.status(500).json({ error: 'Erro interno do servidor' });
        }

        if (!user) {
          return res.status(400).json({ error: 'Token inválido ou expirado' });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);

        database.getDb().run(
          'UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?',
          [hashedPassword, user.id],
          function(err) {
            if (err) {
              return res.status(500).json({ error: 'Erro interno do servidor' });
            }

            res.json({ message: 'Senha alterada com sucesso!' });
          }
        );
      }
    );
  } catch (error) {
    console.error('Erro no reset de senha:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Verificar token (middleware de autenticação)
router.get('/verify-token', authenticateToken, (req, res) => {
  res.json({
    valid: true,
    user: {
      id: req.user.id,
      email: req.user.email,
      name: req.user.name,
      role: req.user.role
    }
  });
});

module.exports = router;

