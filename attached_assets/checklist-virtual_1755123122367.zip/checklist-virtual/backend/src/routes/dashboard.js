const express = require('express');
const database = require('../config/database');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

const router = express.Router();

// Métricas gerais do dashboard
router.get('/metrics', authenticateToken, (req, res) => {
  const { start_date, end_date, template_id } = req.query;
  
  // Construir condições baseadas no papel do usuário
  let whereConditions = [];
  let params = [];
  
  if (req.user.role === 'tecnico') {
    whereConditions.push('assigned_to = ?');
    params.push(req.user.id);
  }
  
  if (start_date) {
    whereConditions.push('created_at >= ?');
    params.push(start_date);
  }
  
  if (end_date) {
    whereConditions.push('created_at <= ?');
    params.push(end_date);
  }
  
  if (template_id) {
    whereConditions.push('template_id = ?');
    params.push(template_id);
  }
  
  const whereClause = whereConditions.length > 0 ? 'WHERE ' + whereConditions.join(' AND ') : '';
  
  // Query para métricas básicas
  const metricsQuery = `
    SELECT 
      COUNT(*) as total_checklists,
      COUNT(CASE WHEN status = 'rascunho' THEN 1 END) as rascunhos,
      COUNT(CASE WHEN status = 'pendente' THEN 1 END) as pendentes,
      COUNT(CASE WHEN status = 'aprovado' THEN 1 END) as aprovados,
      COUNT(CASE WHEN status = 'reprovado' THEN 1 END) as reprovados
    FROM checklist_instances 
    ${whereClause}
  `;
  
  database.getDb().get(metricsQuery, params, (err, metrics) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
    
    res.json({
      total_checklists: metrics.total_checklists || 0,
      rascunhos: metrics.rascunhos || 0,
      pendentes: metrics.pendentes || 0,
      aprovados: metrics.aprovados || 0,
      reprovados: metrics.reprovados || 0,
      taxa_aprovacao: metrics.total_checklists > 0 ? 
        ((metrics.aprovados / (metrics.aprovados + metrics.reprovados)) * 100).toFixed(2) : 0
    });
  });
});

// Métricas por período (últimos 30 dias)
router.get('/metrics/timeline', authenticateToken, (req, res) => {
  const { days = 30 } = req.query;
  
  let whereConditions = [];
  let params = [days];
  
  if (req.user.role === 'tecnico') {
    whereConditions.push('assigned_to = ?');
    params.push(req.user.id);
  }
  
  const whereClause = whereConditions.length > 0 ? 'AND ' + whereConditions.join(' AND ') : '';
  
  const timelineQuery = `
    SELECT 
      DATE(created_at) as date,
      COUNT(*) as total,
      COUNT(CASE WHEN status = 'aprovado' THEN 1 END) as aprovados,
      COUNT(CASE WHEN status = 'reprovado' THEN 1 END) as reprovados,
      COUNT(CASE WHEN status = 'pendente' THEN 1 END) as pendentes
    FROM checklist_instances 
    WHERE created_at >= date('now', '-' || ? || ' days') ${whereClause}
    GROUP BY DATE(created_at)
    ORDER BY date DESC
  `;
  
  database.getDb().all(timelineQuery, params, (err, timeline) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
    
    res.json(timeline);
  });
});

// Métricas por template
router.get('/metrics/templates', authenticateToken, authorizeRoles('admin', 'coordenador', 'analista'), (req, res) => {
  const templatesQuery = `
    SELECT 
      t.id,
      t.name,
      COUNT(i.id) as total_instances,
      COUNT(CASE WHEN i.status = 'aprovado' THEN 1 END) as aprovados,
      COUNT(CASE WHEN i.status = 'reprovado' THEN 1 END) as reprovados,
      COUNT(CASE WHEN i.status = 'pendente' THEN 1 END) as pendentes,
      COUNT(CASE WHEN i.status = 'rascunho' THEN 1 END) as rascunhos
    FROM checklist_templates t
    LEFT JOIN checklist_instances i ON t.id = i.template_id
    GROUP BY t.id, t.name
    ORDER BY total_instances DESC
  `;
  
  database.getDb().all(templatesQuery, [], (err, templates) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
    
    const templatesWithMetrics = templates.map(template => ({
      ...template,
      taxa_aprovacao: (template.aprovados + template.reprovados) > 0 ? 
        ((template.aprovados / (template.aprovados + template.reprovados)) * 100).toFixed(2) : 0
    }));
    
    res.json(templatesWithMetrics);
  });
});

// Métricas por usuário (apenas admin e coordenador)
router.get('/metrics/users', authenticateToken, authorizeRoles('admin', 'coordenador'), (req, res) => {
  const usersQuery = `
    SELECT 
      u.id,
      u.name,
      u.role,
      COUNT(i.id) as total_assigned,
      COUNT(CASE WHEN i.status = 'aprovado' THEN 1 END) as aprovados,
      COUNT(CASE WHEN i.status = 'reprovado' THEN 1 END) as reprovados,
      COUNT(CASE WHEN i.status = 'pendente' THEN 1 END) as pendentes,
      COUNT(CASE WHEN i.status = 'rascunho' THEN 1 END) as rascunhos
    FROM users u
    LEFT JOIN checklist_instances i ON u.id = i.assigned_to
    WHERE u.role IN ('tecnico', 'analista', 'coordenador')
    GROUP BY u.id, u.name, u.role
    ORDER BY total_assigned DESC
  `;
  
  database.getDb().all(usersQuery, [], (err, users) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
    
    const usersWithMetrics = users.map(user => ({
      ...user,
      taxa_conclusao: user.total_assigned > 0 ? 
        (((user.aprovados + user.reprovados) / user.total_assigned) * 100).toFixed(2) : 0
    }));
    
    res.json(usersWithMetrics);
  });
});

// Checklists recentes
router.get('/recent', authenticateToken, (req, res) => {
  const { limit = 10 } = req.query;
  
  let whereConditions = [];
  let params = [limit];
  
  if (req.user.role === 'tecnico') {
    whereConditions.push('i.assigned_to = ?');
    params.push(req.user.id);
  }
  
  const whereClause = whereConditions.length > 0 ? 'WHERE ' + whereConditions.join(' AND ') : '';
  
  const recentQuery = `
    SELECT 
      i.id,
      i.status,
      i.created_at,
      i.updated_at,
      t.name as template_name,
      u1.name as assigned_to_name,
      u2.name as created_by_name
    FROM checklist_instances i
    LEFT JOIN checklist_templates t ON i.template_id = t.id
    LEFT JOIN users u1 ON i.assigned_to = u1.id
    LEFT JOIN users u2 ON i.created_by = u2.id
    ${whereClause}
    ORDER BY i.updated_at DESC
    LIMIT ?
  `;
  
  database.getDb().all(recentQuery, params, (err, recent) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
    
    res.json(recent);
  });
});

// Alertas e notificações
router.get('/alerts', authenticateToken, (req, res) => {
  const alerts = [];
  
  // Para técnicos: checklists reprovados
  if (req.user.role === 'tecnico') {
    database.getDb().all(
      `SELECT i.id, t.name as template_name, i.rejection_reason, i.updated_at
       FROM checklist_instances i
       LEFT JOIN checklist_templates t ON i.template_id = t.id
       WHERE i.assigned_to = ? AND i.status = 'reprovado'
       ORDER BY i.updated_at DESC`,
      [req.user.id],
      (err, reprovados) => {
        if (err) {
          return res.status(500).json({ error: 'Erro interno do servidor' });
        }
        
        reprovados.forEach(item => {
          alerts.push({
            type: 'reprovado',
            message: `Checklist "${item.template_name}" foi reprovado`,
            details: item.rejection_reason,
            checklist_id: item.id,
            date: item.updated_at
          });
        });
        
        res.json(alerts);
      }
    );
  } else {
    // Para outros usuários: checklists pendentes
    database.getDb().all(
      `SELECT i.id, t.name as template_name, u.name as assigned_to_name, i.submitted_at
       FROM checklist_instances i
       LEFT JOIN checklist_templates t ON i.template_id = t.id
       LEFT JOIN users u ON i.assigned_to = u.id
       WHERE i.status = 'pendente'
       ORDER BY i.submitted_at ASC`,
      [],
      (err, pendentes) => {
        if (err) {
          return res.status(500).json({ error: 'Erro interno do servidor' });
        }
        
        pendentes.forEach(item => {
          const daysSinceSubmission = Math.floor(
            (new Date() - new Date(item.submitted_at)) / (1000 * 60 * 60 * 24)
          );
          
          alerts.push({
            type: 'pendente',
            message: `Checklist "${item.template_name}" aguarda aprovação há ${daysSinceSubmission} dias`,
            details: `Atribuído a: ${item.assigned_to_name}`,
            checklist_id: item.id,
            date: item.submitted_at,
            priority: daysSinceSubmission > 3 ? 'high' : 'normal'
          });
        });
        
        res.json(alerts);
      }
    );
  }
});

// Relatório de produtividade
router.get('/productivity', authenticateToken, authorizeRoles('admin', 'coordenador'), (req, res) => {
  const { start_date, end_date } = req.query;
  
  let whereConditions = ['i.status IN ("aprovado", "reprovado")'];
  let params = [];
  
  if (start_date) {
    whereConditions.push('i.created_at >= ?');
    params.push(start_date);
  }
  
  if (end_date) {
    whereConditions.push('i.created_at <= ?');
    params.push(end_date);
  }
  
  const whereClause = 'WHERE ' + whereConditions.join(' AND ');
  
  const productivityQuery = `
    SELECT 
      u.id,
      u.name,
      u.role,
      COUNT(i.id) as total_completed,
      COUNT(CASE WHEN i.status = 'aprovado' THEN 1 END) as aprovados,
      COUNT(CASE WHEN i.status = 'reprovado' THEN 1 END) as reprovados,
      AVG(
        CASE 
          WHEN i.submitted_at IS NOT NULL AND i.created_at IS NOT NULL 
          THEN (julianday(i.submitted_at) - julianday(i.created_at))
          ELSE NULL 
        END
      ) as avg_completion_days
    FROM users u
    LEFT JOIN checklist_instances i ON u.id = i.assigned_to
    ${whereClause}
    GROUP BY u.id, u.name, u.role
    HAVING total_completed > 0
    ORDER BY total_completed DESC
  `;
  
  database.getDb().all(productivityQuery, params, (err, productivity) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
    
    const productivityWithMetrics = productivity.map(user => ({
      ...user,
      taxa_aprovacao: user.total_completed > 0 ? 
        ((user.aprovados / user.total_completed) * 100).toFixed(2) : 0,
      avg_completion_days: user.avg_completion_days ? 
        parseFloat(user.avg_completion_days).toFixed(1) : null
    }));
    
    res.json(productivityWithMetrics);
  });
});

module.exports = router;

