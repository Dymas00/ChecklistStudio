const express = require('express');
const bcrypt = require('bcryptjs');
const database = require('../config/database');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

const router = express.Router();

// Listar usuários (apenas admin e coordenador)
router.get('/', authenticateToken, authorizeRoles('admin', 'coordenador'), (req, res) => {
  const { role } = req.query;
  
  let query = 'SELECT id, email, name, role, is_verified, created_at FROM users';
  let params = [];

  if (role) {
    query += ' WHERE role = ?';
    params.push(role);
  }

  query += ' ORDER BY created_at DESC';

  database.getDb().all(query, params, (err, users) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }

    res.json(users);
  });
});

// Obter usuário por ID
router.get('/:id', authenticateToken, (req, res) => {
  const { id } = req.params;

  // Usuários só podem ver seus próprios dados, exceto admin e coordenador
  if (req.user.role !== 'admin' && req.user.role !== 'coordenador' && req.user.id !== parseInt(id)) {
    return res.status(403).json({ error: 'Acesso negado' });
  }

  database.getDb().get(
    'SELECT id, email, name, role, is_verified, created_at FROM users WHERE id = ?',
    [id],
    (err, user) => {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }

      if (!user) {
        return res.status(404).json({ error: 'Usuário não encontrado' });
      }

      res.json(user);
    }
  );
});

// Criar usuário (apenas admin)
router.post('/', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const { email, password, name, role } = req.body;

    // Validações
    if (!email || !password || !name || !role) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }

    if (!['admin', 'coordenador', 'analista', 'tecnico'].includes(role)) {
      return res.status(400).json({ error: 'Tipo de usuário inválido' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'A senha deve ter pelo menos 6 caracteres' });
    }

    // Verificar se o email já existe
    database.getDb().get(
      'SELECT id FROM users WHERE email = ?',
      [email],
      async (err, existingUser) => {
        if (err) {
          return res.status(500).json({ error: 'Erro interno do servidor' });
        }

        if (existingUser) {
          return res.status(400).json({ error: 'Email já está em uso' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        database.getDb().run(
          `INSERT INTO users (email, password, name, role, is_verified)
           VALUES (?, ?, ?, ?, ?)`,
          [email, hashedPassword, name, role, true], // Admin cria usuários já verificados
          function(err) {
            if (err) {
              return res.status(500).json({ error: 'Erro ao criar usuário' });
            }

            res.status(201).json({
              message: 'Usuário criado com sucesso',
              userId: this.lastID
            });
          }
        );
      }
    );
  } catch (error) {
    console.error('Erro ao criar usuário:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Atualizar usuário
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { email, name, role, password } = req.body;

    // Verificar permissões
    if (req.user.role !== 'admin' && req.user.id !== parseInt(id)) {
      return res.status(403).json({ error: 'Acesso negado' });
    }

    // Apenas admin pode alterar role
    if (role && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Apenas administradores podem alterar o tipo de usuário' });
    }

    // Verificar se o usuário existe
    database.getDb().get(
      'SELECT * FROM users WHERE id = ?',
      [id],
      async (err, user) => {
        if (err) {
          return res.status(500).json({ error: 'Erro interno do servidor' });
        }

        if (!user) {
          return res.status(404).json({ error: 'Usuário não encontrado' });
        }

        // Preparar campos para atualização
        let updateFields = [];
        let updateValues = [];

        if (email && email !== user.email) {
          // Verificar se o novo email já existe
          const existingUser = await new Promise((resolve, reject) => {
            database.getDb().get(
              'SELECT id FROM users WHERE email = ? AND id != ?',
              [email, id],
              (err, row) => {
                if (err) reject(err);
                else resolve(row);
              }
            );
          });

          if (existingUser) {
            return res.status(400).json({ error: 'Email já está em uso' });
          }

          updateFields.push('email = ?');
          updateValues.push(email);
        }

        if (name) {
          updateFields.push('name = ?');
          updateValues.push(name);
        }

        if (role && req.user.role === 'admin') {
          updateFields.push('role = ?');
          updateValues.push(role);
        }

        if (password) {
          if (password.length < 6) {
            return res.status(400).json({ error: 'A senha deve ter pelo menos 6 caracteres' });
          }
          const hashedPassword = await bcrypt.hash(password, 10);
          updateFields.push('password = ?');
          updateValues.push(hashedPassword);
        }

        if (updateFields.length === 0) {
          return res.status(400).json({ error: 'Nenhum campo para atualizar' });
        }

        updateFields.push('updated_at = CURRENT_TIMESTAMP');
        updateValues.push(id);

        const query = `UPDATE users SET ${updateFields.join(', ')} WHERE id = ?`;

        database.getDb().run(query, updateValues, function(err) {
          if (err) {
            return res.status(500).json({ error: 'Erro ao atualizar usuário' });
          }

          res.json({ message: 'Usuário atualizado com sucesso' });
        });
      }
    );
  } catch (error) {
    console.error('Erro ao atualizar usuário:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Deletar usuário (apenas admin)
router.delete('/:id', authenticateToken, authorizeRoles('admin'), (req, res) => {
  const { id } = req.params;

  // Não permitir deletar o próprio usuário
  if (req.user.id === parseInt(id)) {
    return res.status(400).json({ error: 'Não é possível deletar seu próprio usuário' });
  }

  database.getDb().run(
    'DELETE FROM users WHERE id = ?',
    [id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }

      if (this.changes === 0) {
        return res.status(404).json({ error: 'Usuário não encontrado' });
      }

      res.json({ message: 'Usuário deletado com sucesso' });
    }
  );
});

// Obter perfil do usuário logado
router.get('/profile/me', authenticateToken, (req, res) => {
  res.json({
    id: req.user.id,
    email: req.user.email,
    name: req.user.name,
    role: req.user.role
  });
});

module.exports = router;

