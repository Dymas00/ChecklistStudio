const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const database = require('../config/database');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

const router = express.Router();

// Configuração do multer para upload de arquivos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ 
  storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'text/html' || file.originalname.endsWith('.html')) {
      cb(null, true);
    } else {
      cb(new Error('Apenas arquivos HTML são permitidos'), false);
    }
  },
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB
});

// Função para extrair campos do HTML
function parseHtmlFields(htmlContent) {
  const fields = [];
  
  // Regex para encontrar inputs, textareas, selects
  const inputRegex = /<input[^>]*>/gi;
  const textareaRegex = /<textarea[^>]*>.*?<\/textarea>/gi;
  const selectRegex = /<select[^>]*>.*?<\/select>/gi;
  
  let match;
  
  // Processar inputs
  while ((match = inputRegex.exec(htmlContent)) !== null) {
    const input = match[0];
    const nameMatch = input.match(/name\s*=\s*["']([^"']+)["']/i);
    const typeMatch = input.match(/type\s*=\s*["']([^"']+)["']/i);
    const idMatch = input.match(/id\s*=\s*["']([^"']+)["']/i);
    
    if (nameMatch) {
      fields.push({
        name: nameMatch[1],
        type: typeMatch ? typeMatch[1] : 'text',
        id: idMatch ? idMatch[1] : nameMatch[1],
        element: 'input'
      });
    }
  }
  
  // Processar textareas
  while ((match = textareaRegex.exec(htmlContent)) !== null) {
    const textarea = match[0];
    const nameMatch = textarea.match(/name\s*=\s*["']([^"']+)["']/i);
    const idMatch = textarea.match(/id\s*=\s*["']([^"']+)["']/i);
    
    if (nameMatch) {
      fields.push({
        name: nameMatch[1],
        type: 'textarea',
        id: idMatch ? idMatch[1] : nameMatch[1],
        element: 'textarea'
      });
    }
  }
  
  // Processar selects
  while ((match = selectRegex.exec(htmlContent)) !== null) {
    const select = match[0];
    const nameMatch = select.match(/name\s*=\s*["']([^"']+)["']/i);
    const idMatch = select.match(/id\s*=\s*["']([^"']+)["']/i);
    
    if (nameMatch) {
      fields.push({
        name: nameMatch[1],
        type: 'select',
        id: idMatch ? idMatch[1] : nameMatch[1],
        element: 'select'
      });
    }
  }
  
  return fields;
}

// Importar modelo de checklist (apenas admin)
router.post('/templates/import', authenticateToken, authorizeRoles('admin'), upload.single('htmlFile'), (req, res) => {
  try {
    const { name, description } = req.body;
    
    if (!req.file) {
      return res.status(400).json({ error: 'Arquivo HTML é obrigatório' });
    }
    
    if (!name) {
      return res.status(400).json({ error: 'Nome do template é obrigatório' });
    }
    
    // Ler o conteúdo do arquivo HTML
    const htmlContent = fs.readFileSync(req.file.path, 'utf8');
    
    // Extrair campos do HTML
    const fields = parseHtmlFields(htmlContent);
    
    if (fields.length === 0) {
      // Remover arquivo temporário
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: 'Nenhum campo de formulário encontrado no HTML' });
    }
    
    // Salvar no banco de dados
    database.getDb().run(
      `INSERT INTO checklist_templates (name, description, html_content, fields_schema, created_by)
       VALUES (?, ?, ?, ?, ?)`,
      [name, description || '', htmlContent, JSON.stringify(fields), req.user.id],
      function(err) {
        if (err) {
          console.error('Erro ao salvar template:', err);
          fs.unlinkSync(req.file.path);
          return res.status(500).json({ error: 'Erro ao salvar template' });
        }
        
        // Remover arquivo temporário
        fs.unlinkSync(req.file.path);
        
        res.status(201).json({
          message: 'Template importado com sucesso',
          templateId: this.lastID,
          fieldsFound: fields.length,
          fields: fields
        });
      }
    );
  } catch (error) {
    console.error('Erro na importação:', error);
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Listar templates
router.get('/templates', authenticateToken, (req, res) => {
  database.getDb().all(
    `SELECT t.*, u.name as created_by_name 
     FROM checklist_templates t 
     LEFT JOIN users u ON t.created_by = u.id 
     ORDER BY t.created_at DESC`,
    [],
    (err, templates) => {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }
      
      // Parse dos campos para cada template
      const templatesWithFields = templates.map(template => ({
        ...template,
        fields_schema: JSON.parse(template.fields_schema)
      }));
      
      res.json(templatesWithFields);
    }
  );
});

// Obter template por ID
router.get('/templates/:id', authenticateToken, (req, res) => {
  const { id } = req.params;
  
  database.getDb().get(
    `SELECT t.*, u.name as created_by_name 
     FROM checklist_templates t 
     LEFT JOIN users u ON t.created_by = u.id 
     WHERE t.id = ?`,
    [id],
    (err, template) => {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }
      
      if (!template) {
        return res.status(404).json({ error: 'Template não encontrado' });
      }
      
      template.fields_schema = JSON.parse(template.fields_schema);
      res.json(template);
    }
  );
});

// Criar instância de checklist
router.post('/instances', authenticateToken, (req, res) => {
  const { template_id, assigned_to } = req.body;
  
  if (!template_id) {
    return res.status(400).json({ error: 'ID do template é obrigatório' });
  }
  
  // Verificar se o template existe
  database.getDb().get(
    'SELECT id FROM checklist_templates WHERE id = ?',
    [template_id],
    (err, template) => {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }
      
      if (!template) {
        return res.status(404).json({ error: 'Template não encontrado' });
      }
      
      // Criar instância
      database.getDb().run(
        `INSERT INTO checklist_instances (template_id, assigned_to, created_by, status)
         VALUES (?, ?, ?, ?)`,
        [template_id, assigned_to || req.user.id, req.user.id, 'rascunho'],
        function(err) {
          if (err) {
            return res.status(500).json({ error: 'Erro ao criar instância' });
          }
          
          // Registrar no histórico
          database.getDb().run(
            `INSERT INTO checklist_history (checklist_id, user_id, action, details)
             VALUES (?, ?, ?, ?)`,
            [this.lastID, req.user.id, 'criado', 'Checklist criado'],
            () => {}
          );
          
          res.status(201).json({
            message: 'Instância de checklist criada com sucesso',
            instanceId: this.lastID
          });
        }
      );
    }
  );
});

// Listar instâncias de checklist
router.get('/instances', authenticateToken, (req, res) => {
  const { status, template_id } = req.query;
  
  let query = `
    SELECT i.*, t.name as template_name, 
           u1.name as assigned_to_name, u2.name as created_by_name,
           u3.name as approved_by_name
    FROM checklist_instances i
    LEFT JOIN checklist_templates t ON i.template_id = t.id
    LEFT JOIN users u1 ON i.assigned_to = u1.id
    LEFT JOIN users u2 ON i.created_by = u2.id
    LEFT JOIN users u3 ON i.approved_by = u3.id
  `;
  
  let conditions = [];
  let params = [];
  
  // Filtros baseados no papel do usuário
  if (req.user.role === 'tecnico') {
    conditions.push('i.assigned_to = ?');
    params.push(req.user.id);
  }
  
  if (status) {
    conditions.push('i.status = ?');
    params.push(status);
  }
  
  if (template_id) {
    conditions.push('i.template_id = ?');
    params.push(template_id);
  }
  
  if (conditions.length > 0) {
    query += ' WHERE ' + conditions.join(' AND ');
  }
  
  query += ' ORDER BY i.created_at DESC';
  
  database.getDb().all(query, params, (err, instances) => {
    if (err) {
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
    
    // Parse dos dados JSON
    const instancesWithData = instances.map(instance => ({
      ...instance,
      data: instance.data ? JSON.parse(instance.data) : null
    }));
    
    res.json(instancesWithData);
  });
});

// Obter instância por ID
router.get('/instances/:id', authenticateToken, (req, res) => {
  const { id } = req.params;
  
  database.getDb().get(
    `SELECT i.*, t.name as template_name, t.html_content, t.fields_schema,
            u1.name as assigned_to_name, u2.name as created_by_name,
            u3.name as approved_by_name
     FROM checklist_instances i
     LEFT JOIN checklist_templates t ON i.template_id = t.id
     LEFT JOIN users u1 ON i.assigned_to = u1.id
     LEFT JOIN users u2 ON i.created_by = u2.id
     LEFT JOIN users u3 ON i.approved_by = u3.id
     WHERE i.id = ?`,
    [id],
    (err, instance) => {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }
      
      if (!instance) {
        return res.status(404).json({ error: 'Instância não encontrada' });
      }
      
      // Verificar permissões
      if (req.user.role === 'tecnico' && instance.assigned_to !== req.user.id) {
        return res.status(403).json({ error: 'Acesso negado' });
      }
      
      instance.data = instance.data ? JSON.parse(instance.data) : null;
      instance.fields_schema = JSON.parse(instance.fields_schema);
      
      res.json(instance);
    }
  );
});

// Salvar dados da instância
router.put('/instances/:id', authenticateToken, (req, res) => {
  const { id } = req.params;
  const { data, status } = req.body;
  
  // Verificar se a instância existe e se o usuário tem permissão
  database.getDb().get(
    'SELECT * FROM checklist_instances WHERE id = ?',
    [id],
    (err, instance) => {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }
      
      if (!instance) {
        return res.status(404).json({ error: 'Instância não encontrada' });
      }
      
      // Verificar permissões
      if (req.user.role === 'tecnico' && instance.assigned_to !== req.user.id) {
        return res.status(403).json({ error: 'Acesso negado' });
      }
      
      // Não permitir edição de checklists aprovados
      if (instance.status === 'aprovado') {
        return res.status(400).json({ error: 'Checklist aprovado não pode ser editado' });
      }
      
      let updateFields = [];
      let updateValues = [];
      
      if (data) {
        updateFields.push('data = ?');
        updateValues.push(JSON.stringify(data));
      }
      
      if (status) {
        updateFields.push('status = ?');
        updateValues.push(status);
        
        if (status === 'pendente') {
          updateFields.push('submitted_at = CURRENT_TIMESTAMP');
        }
      }
      
      updateFields.push('updated_at = CURRENT_TIMESTAMP');
      updateValues.push(id);
      
      const query = `UPDATE checklist_instances SET ${updateFields.join(', ')} WHERE id = ?`;
      
      database.getDb().run(query, updateValues, function(err) {
        if (err) {
          return res.status(500).json({ error: 'Erro ao salvar dados' });
        }
        
        // Registrar no histórico
        let action = 'atualizado';
        if (status === 'pendente') {
          action = 'submetido para aprovação';
        }
        
        database.getDb().run(
          `INSERT INTO checklist_history (checklist_id, user_id, action, details)
           VALUES (?, ?, ?, ?)`,
          [id, req.user.id, action, `Status: ${status || instance.status}`],
          () => {}
        );
        
        res.json({ message: 'Dados salvos com sucesso' });
      });
    }
  );
});

// Aprovar/Reprovar checklist
router.post('/instances/:id/review', authenticateToken, authorizeRoles('admin', 'coordenador', 'analista'), (req, res) => {
  const { id } = req.params;
  const { action, comments } = req.body; // action: 'aprovar' ou 'reprovar'
  
  if (!action || !['aprovar', 'reprovar'].includes(action)) {
    return res.status(400).json({ error: 'Ação inválida. Use "aprovar" ou "reprovar"' });
  }
  
  if (action === 'reprovar' && !comments) {
    return res.status(400).json({ error: 'Comentários são obrigatórios para reprovação' });
  }
  
  database.getDb().get(
    'SELECT * FROM checklist_instances WHERE id = ?',
    [id],
    (err, instance) => {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }
      
      if (!instance) {
        return res.status(404).json({ error: 'Instância não encontrada' });
      }
      
      if (instance.status !== 'pendente') {
        return res.status(400).json({ error: 'Apenas checklists pendentes podem ser revisados' });
      }
      
      const newStatus = action === 'aprovar' ? 'aprovado' : 'reprovado';
      
      let updateFields = ['status = ?', 'approved_by = ?', 'updated_at = CURRENT_TIMESTAMP'];
      let updateValues = [newStatus, req.user.id];
      
      if (action === 'aprovar') {
        updateFields.push('approved_at = CURRENT_TIMESTAMP');
      } else {
        updateFields.push('rejection_reason = ?');
        updateValues.push(comments);
      }
      
      updateValues.push(id);
      
      const query = `UPDATE checklist_instances SET ${updateFields.join(', ')} WHERE id = ?`;
      
      database.getDb().run(query, updateValues, function(err) {
        if (err) {
          return res.status(500).json({ error: 'Erro ao processar revisão' });
        }
        
        // Registrar no histórico
        database.getDb().run(
          `INSERT INTO checklist_history (checklist_id, user_id, action, details)
           VALUES (?, ?, ?, ?)`,
          [id, req.user.id, action, comments || `Checklist ${newStatus}`],
          () => {}
        );
        
        res.json({ 
          message: `Checklist ${action === 'aprovar' ? 'aprovado' : 'reprovado'} com sucesso`,
          status: newStatus
        });
      });
    }
  );
});

// Obter histórico de uma instância
router.get('/instances/:id/history', authenticateToken, (req, res) => {
  const { id } = req.params;
  
  database.getDb().all(
    `SELECT h.*, u.name as user_name
     FROM checklist_history h
     LEFT JOIN users u ON h.user_id = u.id
     WHERE h.checklist_id = ?
     ORDER BY h.created_at DESC`,
    [id],
    (err, history) => {
      if (err) {
        return res.status(500).json({ error: 'Erro interno do servidor' });
      }
      
      res.json(history);
    }
  );
});

module.exports = router;

