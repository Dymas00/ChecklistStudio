const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, '../../database.sqlite');

class Database {
  constructor() {
    this.db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        console.error('Erro ao conectar com o banco de dados:', err.message);
      } else {
        console.log('Conectado ao banco de dados SQLite.');
        this.initializeTables();
      }
    });
  }

  initializeTables() {
    // Tabela de usuários
    this.db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin', 'coordenador', 'analista', 'tecnico')),
        is_verified BOOLEAN DEFAULT FALSE,
        verification_token TEXT,
        reset_token TEXT,
        reset_token_expires DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `, (err) => {
      if (err) {
        console.error('Erro ao criar tabela users:', err);
      } else {
        console.log('Tabela users criada/verificada com sucesso');
        this.createDefaultAdmin();
      }
    });

    // Tabela de modelos de checklist
    this.db.run(`
      CREATE TABLE IF NOT EXISTS checklist_templates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        html_content TEXT NOT NULL,
        fields_schema TEXT NOT NULL,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users (id)
      )
    `, (err) => {
      if (err) {
        console.error('Erro ao criar tabela checklist_templates:', err);
      } else {
        console.log('Tabela checklist_templates criada/verificada com sucesso');
      }
    });

    // Tabela de instâncias de checklist
    this.db.run(`
      CREATE TABLE IF NOT EXISTS checklist_instances (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        template_id INTEGER NOT NULL,
        assigned_to INTEGER,
        created_by INTEGER,
        status TEXT NOT NULL DEFAULT 'rascunho' CHECK(status IN ('rascunho', 'pendente', 'aprovado', 'reprovado')),
        data TEXT,
        comments TEXT,
        rejection_reason TEXT,
        approved_by INTEGER,
        approved_at DATETIME,
        submitted_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (template_id) REFERENCES checklist_templates (id),
        FOREIGN KEY (assigned_to) REFERENCES users (id),
        FOREIGN KEY (created_by) REFERENCES users (id),
        FOREIGN KEY (approved_by) REFERENCES users (id)
      )
    `, (err) => {
      if (err) {
        console.error('Erro ao criar tabela checklist_instances:', err);
      } else {
        console.log('Tabela checklist_instances criada/verificada com sucesso');
      }
    });

    // Tabela de histórico de ações
    this.db.run(`
      CREATE TABLE IF NOT EXISTS checklist_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        checklist_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        details TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (checklist_id) REFERENCES checklist_instances (id),
        FOREIGN KEY (user_id) REFERENCES users (id)
      )
    `, (err) => {
      if (err) {
        console.error('Erro ao criar tabela checklist_history:', err);
      } else {
        console.log('Tabela checklist_history criada/verificada com sucesso');
      }
    });
  }

  createDefaultAdmin() {
    const bcrypt = require('bcryptjs');
    const defaultPassword = bcrypt.hashSync('admin123', 10);
    
    this.db.get('SELECT id FROM users WHERE email = ?', ['admin@checklist.com'], (err, row) => {
      if (err) {
        console.error('Erro ao verificar admin padrão:', err);
        return;
      }
      
      if (!row) {
        this.db.run(`
          INSERT INTO users (email, password, name, role, is_verified)
          VALUES (?, ?, ?, ?, ?)
        `, ['admin@checklist.com', defaultPassword, 'Administrador', 'admin', true], (err) => {
          if (err) {
            console.error('Erro ao criar admin padrão:', err);
          } else {
            console.log('Usuário admin padrão criado: admin@checklist.com / admin123');
          }
        });
      }
    });
  }

  getDb() {
    return this.db;
  }

  close() {
    this.db.close((err) => {
      if (err) {
        console.error('Erro ao fechar o banco de dados:', err.message);
      } else {
        console.log('Conexão com o banco de dados fechada.');
      }
    });
  }
}

const database = new Database();
module.exports = database;

