const jwt = require('jsonwebtoken');
const database = require('../config/database');

const JWT_SECRET = process.env.JWT_SECRET || 'checklist_virtual_secret_key_2024';

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token de acesso requerido' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Token inválido' });
    }

    // Verificar se o usuário ainda existe no banco
    database.getDb().get(
      'SELECT id, email, name, role, is_verified FROM users WHERE id = ?',
      [user.id],
      (err, dbUser) => {
        if (err) {
          return res.status(500).json({ error: 'Erro interno do servidor' });
        }

        if (!dbUser) {
          return res.status(401).json({ error: 'Usuário não encontrado' });
        }

        if (!dbUser.is_verified) {
          return res.status(401).json({ error: 'Usuário não verificado' });
        }

        req.user = dbUser;
        next();
      }
    );
  });
};

const authorizeRoles = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Usuário não autenticado' });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Acesso negado. Permissão insuficiente.' });
    }

    next();
  };
};

const generateToken = (user) => {
  return jwt.sign(
    { 
      id: user.id, 
      email: user.email, 
      role: user.role 
    },
    JWT_SECRET,
    { expiresIn: '24h' }
  );
};

module.exports = {
  authenticateToken,
  authorizeRoles,
  generateToken,
  JWT_SECRET
};

