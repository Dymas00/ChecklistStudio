// Utilitário para envio de emails
// Em produção, configure com um provedor real como SendGrid, Mailgun, etc.

const sendVerificationEmail = async (email, token) => {
  try {
    // Simular envio de email
    console.log('=== EMAIL DE VERIFICAÇÃO ===');
    console.log(`Para: ${email}`);
    console.log(`Assunto: Verificação de conta - Checklist Virtual`);
    console.log(`Link de verificação: http://localhost:3000/verify/${token}`);
    console.log('============================');
    
    // Em produção, implementar envio real:
    /*
    const nodemailer = require('nodemailer');
    
    const transporter = nodemailer.createTransporter({
      service: 'gmail', // ou outro provedor
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });
    
    const mailOptions = {
      from: process.env.EMAIL_FROM,
      to: email,
      subject: 'Verificação de conta - Checklist Virtual',
      html: `
        <h2>Bem-vindo ao Checklist Virtual!</h2>
        <p>Clique no link abaixo para verificar sua conta:</p>
        <a href="${process.env.FRONTEND_URL}/verify/${token}">Verificar Conta</a>
        <p>Este link expira em 24 horas.</p>
      `
    };
    
    await transporter.sendMail(mailOptions);
    */
    
    return { success: true };
  } catch (error) {
    console.error('Erro ao enviar email de verificação:', error);
    return { success: false, error: error.message };
  }
};

const sendPasswordResetEmail = async (email, token) => {
  try {
    // Simular envio de email
    console.log('=== EMAIL DE RESET DE SENHA ===');
    console.log(`Para: ${email}`);
    console.log(`Assunto: Recuperação de senha - Checklist Virtual`);
    console.log(`Link de reset: http://localhost:3000/reset-password/${token}`);
    console.log('===============================');
    
    // Em produção, implementar envio real similar ao exemplo acima
    
    return { success: true };
  } catch (error) {
    console.error('Erro ao enviar email de reset:', error);
    return { success: false, error: error.message };
  }
};

const sendNotificationEmail = async (email, subject, message) => {
  try {
    // Simular envio de email
    console.log('=== EMAIL DE NOTIFICAÇÃO ===');
    console.log(`Para: ${email}`);
    console.log(`Assunto: ${subject}`);
    console.log(`Mensagem: ${message}`);
    console.log('============================');
    
    return { success: true };
  } catch (error) {
    console.error('Erro ao enviar email de notificação:', error);
    return { success: false, error: error.message };
  }
};

module.exports = {
  sendVerificationEmail,
  sendPasswordResetEmail,
  sendNotificationEmail
};

