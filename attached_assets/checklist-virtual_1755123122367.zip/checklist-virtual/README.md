# Checklist Virtual

Sistema completo de gerenciamento de checklists virtuais com interface web moderna e backend robusto.

## 📋 Sobre o Projeto

O Checklist Virtual é uma aplicação web completa que permite:

- **Gestão de Usuários**: Sistema de autenticação com diferentes níveis de acesso (Admin, Coordenador, Analista, Técnico)
- **Templates de Checklist**: Importação de templates HTML para criação de checklists personalizados
- **Instâncias de Checklist**: Criação e gerenciamento de checklists baseados nos templates
- **Dashboard Administrativo**: Visão geral com estatísticas e métricas do sistema
- **Interface Responsiva**: Design moderno e responsivo que funciona em desktop e mobile

## 🏗️ Arquitetura

### Backend (Node.js + Express)
- **Framework**: Express.js 4.x
- **Banco de Dados**: SQLite (para desenvolvimento)
- **Autenticação**: JWT (JSON Web Tokens)
- **Segurança**: bcryptjs para hash de senhas, rate limiting
- **Upload de Arquivos**: Multer para processamento de templates HTML

### Frontend (React + Vite)
- **Framework**: React 18 com Vite
- **Roteamento**: React Router DOM
- **Estilização**: Tailwind CSS com componentes customizados
- **Formulários**: React Hook Form com validação
- **Estado**: Context API para gerenciamento de autenticação
- **Notificações**: React Hot Toast

## 🚀 Pré-requisitos

Antes de executar o projeto, certifique-se de ter instalado:

- **Node.js** (versão 18 ou superior)
- **npm** ou **pnpm** (recomendado)

### Verificando as versões:
```bash
node --version
npm --version
# ou
pnpm --version
```

## 📦 Instalação

### 1. Extrair o projeto
Extraia o arquivo ZIP em uma pasta de sua escolha.

### 2. Instalar dependências do Backend
```bash
cd backend
npm install
```

### 3. Instalar dependências do Frontend
```bash
cd ../frontend
npm install
# ou se preferir usar pnpm:
pnpm install
```

### 4. Configurar variáveis de ambiente

#### Backend (.env)
Crie um arquivo `.env` na pasta `backend` baseado no `.env.example`:
```bash
cd backend
cp .env.example .env
```

Edite o arquivo `.env` conforme necessário:
```env
NODE_ENV=development
PORT=3001
JWT_SECRET=seu_jwt_secret_muito_seguro_aqui
DB_PATH=./database.sqlite
FRONTEND_URL=http://localhost:5173
```

#### Frontend (.env)
Crie um arquivo `.env` na pasta `frontend` baseado no `.env.example`:
```bash
cd ../frontend
cp .env.example .env
```

O arquivo `.env` do frontend deve conter:
```env
VITE_API_URL=http://localhost:3001/api
```

## 🎯 Executando o Projeto

### Método 1: Execução Manual (Recomendado para desenvolvimento)

#### 1. Iniciar o Backend
```bash
cd backend
npm start
# ou para desenvolvimento com auto-reload:
npm run dev
```

O backend estará disponível em: `http://localhost:3001`

#### 2. Iniciar o Frontend (em outro terminal)
```bash
cd frontend
npm run dev
# ou com pnpm:
pnpm run dev
```

O frontend estará disponível em: `http://localhost:5173`

### Método 2: Usando Scripts de Conveniência

Você pode criar scripts para facilitar a execução:

#### Windows (start.bat)
```batch
@echo off
echo Iniciando Checklist Virtual...
start cmd /k "cd backend && npm start"
timeout /t 3
start cmd /k "cd frontend && npm run dev"
echo Serviços iniciados!
echo Backend: http://localhost:3001
echo Frontend: http://localhost:5173
pause
```

#### Linux/Mac (start.sh)
```bash
#!/bin/bash
echo "Iniciando Checklist Virtual..."
cd backend && npm start &
sleep 3
cd ../frontend && npm run dev &
echo "Serviços iniciados!"
echo "Backend: http://localhost:3001"
echo "Frontend: http://localhost:5173"
wait
```

## 👤 Acesso Inicial

Após iniciar a aplicação, acesse `http://localhost:5173` e faça login com:

- **Email**: admin@checklist.com
- **Senha**: admin123

> ⚠️ **Importante**: Altere a senha padrão após o primeiro acesso!

## 📁 Estrutura do Projeto

```
checklist-virtual/
├── backend/                 # Servidor Node.js
│   ├── src/
│   │   ├── config/         # Configurações (banco, etc)
│   │   ├── controllers/    # Controladores das rotas
│   │   ├── middleware/     # Middlewares (auth, etc)
│   │   ├── routes/         # Definição das rotas
│   │   ├── utils/          # Utilitários
│   │   └── server.js       # Arquivo principal
│   ├── uploads/            # Arquivos enviados
│   ├── .env.example        # Exemplo de variáveis de ambiente
│   └── package.json
├── frontend/               # Aplicação React
│   ├── src/
│   │   ├── components/     # Componentes React
│   │   ├── hooks/          # Hooks customizados
│   │   ├── lib/            # Bibliotecas e utilitários
│   │   └── App.jsx         # Componente principal
│   ├── public/             # Arquivos estáticos
│   ├── .env.example        # Exemplo de variáveis de ambiente
│   └── package.json
└── README.md               # Este arquivo
```

## 🔧 Funcionalidades Principais

### 1. Gestão de Usuários
- Criação, edição e exclusão de usuários
- Diferentes níveis de acesso (Admin, Coordenador, Analista, Técnico)
- Sistema de autenticação seguro com JWT

### 2. Templates de Checklist
- Importação de arquivos HTML como templates
- Extração automática de campos de formulário
- Gerenciamento de templates existentes

### 3. Instâncias de Checklist
- Criação de checklists baseados em templates
- Preenchimento e submissão de checklists
- Aprovação/reprovação por coordenadores
- Histórico de ações

### 4. Dashboard
- Estatísticas em tempo real
- Visão geral do sistema
- Alertas e notificações

## 🛠️ Desenvolvimento

### Scripts Disponíveis

#### Backend
```bash
npm start          # Inicia o servidor
npm run dev        # Inicia com nodemon (auto-reload)
npm test           # Executa testes (se configurados)
```

#### Frontend
```bash
npm run dev        # Servidor de desenvolvimento
npm run build      # Build para produção
npm run preview    # Preview do build
npm run lint       # Verificação de código
```

### Adicionando Novas Funcionalidades

1. **Backend**: Adicione rotas em `src/routes/`, controladores em `src/controllers/`
2. **Frontend**: Crie componentes em `src/components/`, páginas seguindo a estrutura existente

## 🐛 Solução de Problemas

### Erro de CORS
Se encontrar erros de CORS, verifique se:
- O backend está rodando na porta 3001
- O frontend está configurado para acessar `http://localhost:3001/api`
- As configurações de CORS no backend incluem a URL do frontend

### Erro de Banco de Dados
Se houver problemas com o banco:
- Verifique se o arquivo `database.sqlite` foi criado na pasta `backend`
- Delete o arquivo e reinicie o backend para recriar as tabelas

### Problemas de Dependências
```bash
# Limpar cache e reinstalar
rm -rf node_modules package-lock.json
npm install
```

### Portas em Uso
Se as portas estiverem ocupadas:
- Backend: Altere `PORT` no arquivo `.env`
- Frontend: Use `npm run dev -- --port 3000` para mudar a porta

## 📝 Licença

Este projeto foi desenvolvido como uma solução personalizada. Todos os direitos reservados.

## 🤝 Suporte

Para suporte ou dúvidas sobre o projeto, consulte a documentação ou entre em contato com a equipe de desenvolvimento.

---

**Desenvolvido com ❤️ usando Node.js, React e tecnologias modernas**

