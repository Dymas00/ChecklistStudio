#!/bin/bash

echo "🚀 Iniciando Checklist Virtual..."
echo ""

# Verificar se Node.js está instalado
if ! command -v node &> /dev/null; then
    echo "❌ Node.js não encontrado. Por favor, instale o Node.js primeiro."
    echo "   Visite: https://nodejs.org/"
    exit 1
fi

# Verificar se as dependências estão instaladas
if [ ! -d "backend/node_modules" ]; then
    echo "📦 Instalando dependências do backend..."
    cd backend && npm install
    cd ..
fi

if [ ! -d "frontend/node_modules" ]; then
    echo "📦 Instalando dependências do frontend..."
    cd frontend && npm install
    cd ..
fi

# Verificar arquivos .env
if [ ! -f "backend/.env" ]; then
    echo "⚙️  Criando arquivo .env do backend..."
    cp backend/.env.example backend/.env
fi

if [ ! -f "frontend/.env" ]; then
    echo "⚙️  Criando arquivo .env do frontend..."
    cp frontend/.env.example frontend/.env
fi

echo ""
echo "🎯 Iniciando serviços..."
echo ""

# Iniciar backend em background
echo "🔧 Iniciando backend na porta 3001..."
cd backend && npm start &
BACKEND_PID=$!

# Aguardar um pouco para o backend inicializar
sleep 5

# Iniciar frontend
echo "🎨 Iniciando frontend na porta 5173..."
cd ../frontend && npm run dev &
FRONTEND_PID=$!

echo ""
echo "✅ Serviços iniciados com sucesso!"
echo ""
echo "🌐 Acesse a aplicação em: http://localhost:5173"
echo "🔧 API disponível em: http://localhost:3001"
echo ""
echo "👤 Credenciais de acesso:"
echo "   Email: admin@checklist.com"
echo "   Senha: admin123"
echo ""
echo "⚠️  Pressione Ctrl+C para parar os serviços"
echo ""

# Função para limpar processos ao sair
cleanup() {
    echo ""
    echo "🛑 Parando serviços..."
    kill $BACKEND_PID 2>/dev/null
    kill $FRONTEND_PID 2>/dev/null
    echo "✅ Serviços parados."
    exit 0
}

# Capturar Ctrl+C
trap cleanup SIGINT

# Aguardar indefinidamente
wait

