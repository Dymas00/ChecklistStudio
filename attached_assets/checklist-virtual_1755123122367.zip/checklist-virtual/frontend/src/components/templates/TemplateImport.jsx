import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { checklistService } from '../../lib/api';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { ArrowLeft, Upload, FileText } from 'lucide-react';
import LoadingSpinner from '../ui/LoadingSpinner';
import toast from 'react-hot-toast';

const TemplateImport = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
  });
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      if (selectedFile.type === 'text/html' || selectedFile.name.endsWith('.html')) {
        setFile(selectedFile);
      } else {
        toast.error('Apenas arquivos HTML são permitidos');
        e.target.value = '';
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast.error('Nome do template é obrigatório');
      return;
    }

    if (!file) {
      toast.error('Arquivo HTML é obrigatório');
      return;
    }

    setLoading(true);

    try {
      const formDataToSend = new FormData();
      formDataToSend.append('name', formData.name);
      formDataToSend.append('description', formData.description);
      formDataToSend.append('htmlFile', file);

      const result = await checklistService.importTemplate(formDataToSend);
      
      toast.success(`Template importado com sucesso! ${result.fieldsFound} campos encontrados.`);
      navigate('/templates');
    } catch (error) {
      console.error('Erro ao importar template:', error);
      const message = error.response?.data?.error || 'Erro ao importar template';
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    navigate('/templates');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="outline" size="sm" onClick={handleBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            Importar Template
          </h1>
          <p className="text-muted-foreground">
            Importe um arquivo HTML para criar um novo template de checklist
          </p>
        </div>
      </div>

      {/* Form */}
      <div className="max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>Dados do Template</CardTitle>
            <CardDescription>
              Preencha as informações do template e selecione o arquivo HTML
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Nome do Template *</Label>
                <Input
                  id="name"
                  name="name"
                  type="text"
                  placeholder="Ex: Checklist de Segurança"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descrição</Label>
                <Textarea
                  id="description"
                  name="description"
                  placeholder="Descrição opcional do template"
                  value={formData.description}
                  onChange={handleChange}
                  disabled={loading}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="htmlFile">Arquivo HTML *</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    id="htmlFile"
                    type="file"
                    accept=".html,text/html"
                    onChange={handleFileChange}
                    required
                    disabled={loading}
                    className="file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-primary file:text-primary-foreground hover:file:bg-primary/90"
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  Selecione um arquivo HTML contendo campos de formulário (input, textarea, select)
                </p>
              </div>

              <div className="flex space-x-4">
                <Button
                  type="submit"
                  disabled={loading}
                  className="flex-1"
                >
                  {loading ? (
                    <>
                      <LoadingSpinner size="sm" className="mr-2" />
                      Importando...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Importar Template
                    </>
                  )}
                </Button>
                
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleBack}
                  disabled={loading}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Instruções */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="mr-2 h-5 w-5" />
              Instruções para o Arquivo HTML
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-sm text-muted-foreground space-y-2">
              <p>O arquivo HTML deve conter campos de formulário com os atributos <code>name</code> definidos:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li><code>&lt;input name="campo1" type="text" /&gt;</code></li>
                <li><code>&lt;textarea name="campo2"&gt;&lt;/textarea&gt;</code></li>
                <li><code>&lt;select name="campo3"&gt;&lt;option&gt;...&lt;/option&gt;&lt;/select&gt;</code></li>
              </ul>
              <p>O sistema extrairá automaticamente todos os campos e criará a estrutura do checklist.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TemplateImport;

