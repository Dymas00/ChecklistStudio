import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { checklistService } from '../../lib/api';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Plus, Upload, FileText } from 'lucide-react';
import LoadingSpinner from '../ui/LoadingSpinner';

const TemplateList = () => {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      setLoading(true);
      const data = await checklistService.getTemplates();
      setTemplates(data);
    } catch (error) {
      console.error('Erro ao carregar templates:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Templates</h1>
          <p className="text-muted-foreground">
            Gerencie os modelos de checklist
          </p>
        </div>
        <Button asChild>
          <Link to="/templates/import">
            <Upload className="mr-2 h-4 w-4" />
            Importar Template
          </Link>
        </Button>
      </div>

      {/* Lista de Templates */}
      {templates.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template) => (
            <Card key={template.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{template.name}</CardTitle>
                    <CardDescription>
                      {template.description || 'Sem descrição'}
                    </CardDescription>
                  </div>
                  <FileText className="h-5 w-5 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm text-muted-foreground">
                    <p>Campos: {template.fields_schema?.length || 0}</p>
                    <p>Criado por: {template.created_by_name}</p>
                    <p>Data: {new Date(template.created_at).toLocaleDateString('pt-BR')}</p>
                  </div>

                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      Visualizar
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      Usar Template
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <FileText className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">
              Nenhum template encontrado
            </h3>
            <p className="text-muted-foreground text-center mb-4">
              Você ainda não tem templates. Importe seu primeiro template para começar.
            </p>
            <Button asChild>
              <Link to="/templates/import">
                <Upload className="mr-2 h-4 w-4" />
                Importar Primeiro Template
              </Link>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default TemplateList;

