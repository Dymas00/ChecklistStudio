import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { checklistService } from '../../lib/api';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { ArrowLeft } from 'lucide-react';
import LoadingSpinner from '../ui/LoadingSpinner';

const ChecklistForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const isEdit = Boolean(id);

  const handleBack = () => {
    navigate('/checklists');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="outline" size="sm" onClick={handleBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            {isEdit ? 'Editar Checklist' : 'Novo Checklist'}
          </h1>
          <p className="text-muted-foreground">
            {isEdit ? 'Edite os dados do checklist' : 'Crie um novo checklist'}
          </p>
        </div>
      </div>

      {/* Form */}
      <Card>
        <CardHeader>
          <CardTitle>Formulário de Checklist</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <p className="text-muted-foreground mb-4">
                Funcionalidade em desenvolvimento
              </p>
              <Button onClick={handleBack}>
                Voltar para Lista
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChecklistForm;

