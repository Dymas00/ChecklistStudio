import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { checklistService } from '../../lib/api';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Plus, Eye, Edit, CheckCircle, XCircle, Clock, AlertCircle } from 'lucide-react';
import LoadingSpinner from '../ui/LoadingSpinner';

const ChecklistList = () => {
  const { user } = useAuth();
  const [checklists, setChecklists] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadChecklists();
  }, []);

  const loadChecklists = async () => {
    try {
      setLoading(true);
      const data = await checklistService.getInstances();
      setChecklists(data);
    } catch (error) {
      console.error('Erro ao carregar checklists:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'aprovado':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'reprovado':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'pendente':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusVariant = (status) => {
    switch (status) {
      case 'aprovado':
        return 'default';
      case 'reprovado':
        return 'destructive';
      case 'pendente':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'aprovado':
        return 'Aprovado';
      case 'reprovado':
        return 'Reprovado';
      case 'pendente':
        return 'Pendente';
      case 'rascunho':
        return 'Rascunho';
      default:
        return status;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Checklists</h1>
          <p className="text-muted-foreground">
            Gerencie seus checklists
          </p>
        </div>
        <Button asChild>
          <Link to="/checklists/new">
            <Plus className="mr-2 h-4 w-4" />
            Novo Checklist
          </Link>
        </Button>
      </div>

      {/* Lista de Checklists */}
      {checklists.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {checklists.map((checklist) => (
            <Card key={checklist.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{checklist.template_name}</CardTitle>
                    <CardDescription>
                      {checklist.assigned_to_name && (
                        <span>Atribuído a: {checklist.assigned_to_name}</span>
                      )}
                    </CardDescription>
                  </div>
                  <div className="flex items-center space-x-1">
                    {getStatusIcon(checklist.status)}
                    <Badge variant={getStatusVariant(checklist.status)}>
                      {getStatusText(checklist.status)}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm text-muted-foreground">
                    <p>Criado em: {new Date(checklist.created_at).toLocaleDateString('pt-BR')}</p>
                    {checklist.updated_at !== checklist.created_at && (
                      <p>Atualizado em: {new Date(checklist.updated_at).toLocaleDateString('pt-BR')}</p>
                    )}
                  </div>

                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" asChild className="flex-1">
                      <Link to={`/checklists/${checklist.id}`}>
                        <Eye className="mr-2 h-4 w-4" />
                        Visualizar
                      </Link>
                    </Button>
                    
                    {(checklist.status === 'rascunho' || checklist.status === 'reprovado') && 
                     (user?.role !== 'tecnico' || checklist.assigned_to === user?.id) && (
                      <Button variant="outline" size="sm" asChild className="flex-1">
                        <Link to={`/checklists/${checklist.id}/edit`}>
                          <Edit className="mr-2 h-4 w-4" />
                          Editar
                        </Link>
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <CheckCircle className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">
              Nenhum checklist encontrado
            </h3>
            <p className="text-muted-foreground text-center mb-4">
              Você ainda não tem checklists. Crie seu primeiro checklist para começar.
            </p>
            <Button asChild>
              <Link to="/checklists/new">
                <Plus className="mr-2 h-4 w-4" />
                Criar Primeiro Checklist
              </Link>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ChecklistList;

