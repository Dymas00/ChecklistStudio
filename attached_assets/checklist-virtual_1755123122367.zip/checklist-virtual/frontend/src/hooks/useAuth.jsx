import { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '../lib/api';
import toast from 'react-hot-toast';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      const token = localStorage.getItem('token');
      const savedUser = localStorage.getItem('user');

      if (token && savedUser) {
        // Verificar se o token ainda é válido
        const response = await authService.verifyToken();
        setUser(response.user);
        setIsAuthenticated(true);
      }
    } catch (error) {
      // Token inválido ou expirado
      logout();
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password) => {
    try {
      const response = await authService.login(email, password);
      
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
      
      setUser(response.user);
      setIsAuthenticated(true);
      
      toast.success('Login realizado com sucesso!');
      return { success: true };
    } catch (error) {
      const message = error.response?.data?.error || 'Erro ao fazer login';
      toast.error(message);
      return { success: false, error: message };
    }
  };

  const register = async (userData) => {
    try {
      const response = await authService.register(userData);
      toast.success('Usuário registrado com sucesso! Verifique seu email.');
      return { success: true, data: response };
    } catch (error) {
      const message = error.response?.data?.error || 'Erro ao registrar usuário';
      toast.error(message);
      return { success: false, error: message };
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setIsAuthenticated(false);
    toast.success('Logout realizado com sucesso!');
  };

  const forgotPassword = async (email) => {
    try {
      const response = await authService.forgotPassword(email);
      toast.success('Email de recuperação enviado!');
      return { success: true, data: response };
    } catch (error) {
      const message = error.response?.data?.error || 'Erro ao enviar email de recuperação';
      toast.error(message);
      return { success: false, error: message };
    }
  };

  const resetPassword = async (token, newPassword) => {
    try {
      const response = await authService.resetPassword(token, newPassword);
      toast.success('Senha alterada com sucesso!');
      return { success: true, data: response };
    } catch (error) {
      const message = error.response?.data?.error || 'Erro ao alterar senha';
      toast.error(message);
      return { success: false, error: message };
    }
  };

  const hasRole = (roles) => {
    if (!user) return false;
    if (Array.isArray(roles)) {
      return roles.includes(user.role);
    }
    return user.role === roles;
  };

  const canManageUsers = () => {
    return hasRole(['admin', 'coordenador']);
  };

  const canReviewChecklists = () => {
    return hasRole(['admin', 'coordenador', 'analista']);
  };

  const canImportTemplates = () => {
    return hasRole('admin');
  };

  const value = {
    user,
    loading,
    isAuthenticated,
    login,
    register,
    logout,
    forgotPassword,
    resetPassword,
    hasRole,
    canManageUsers,
    canReviewChecklists,
    canImportTemplates,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

