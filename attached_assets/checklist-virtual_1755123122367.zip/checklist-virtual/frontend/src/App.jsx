import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './hooks/useAuth';
import Layout from './components/Layout';
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import Dashboard from './components/Dashboard';
import ChecklistList from './components/checklists/ChecklistList';
import ChecklistForm from './components/checklists/ChecklistForm';
import ChecklistView from './components/checklists/ChecklistView';
import TemplateList from './components/templates/TemplateList';
import TemplateImport from './components/templates/TemplateImport';
import UserList from './components/users/UserList';
import UserForm from './components/users/UserForm';
import LoadingSpinner from './components/ui/LoadingSpinner';
import './App.css';

// Componente para rotas protegidas
const ProtectedRoute = ({ children, roles }) => {
  const { isAuthenticated, user, loading } = useAuth();

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (roles && !roles.includes(user?.role)) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

// Componente para rotas públicas (apenas para usuários não autenticados)
const PublicRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return <LoadingSpinner />;
  }

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

function AppContent() {
  return (
    <Router>
      <div className="min-h-screen bg-background">
        <Routes>
          {/* Rotas públicas */}
          <Route
            path="/login"
            element={
              <PublicRoute>
                <Login />
              </PublicRoute>
            }
          />
          <Route
            path="/register"
            element={
              <PublicRoute>
                <Register />
              </PublicRoute>
            }
          />

          {/* Rotas protegidas */}
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }
          >
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard" element={<Dashboard />} />
            
            {/* Checklists */}
            <Route path="checklists" element={<ChecklistList />} />
            <Route path="checklists/new" element={<ChecklistForm />} />
            <Route path="checklists/:id" element={<ChecklistView />} />
            <Route path="checklists/:id/edit" element={<ChecklistForm />} />

            {/* Templates (apenas admin) */}
            <Route
              path="templates"
              element={
                <ProtectedRoute roles={['admin']}>
                  <TemplateList />
                </ProtectedRoute>
              }
            />
            <Route
              path="templates/import"
              element={
                <ProtectedRoute roles={['admin']}>
                  <TemplateImport />
                </ProtectedRoute>
              }
            />

            {/* Usuários (admin e coordenador) */}
            <Route
              path="users"
              element={
                <ProtectedRoute roles={['admin', 'coordenador']}>
                  <UserList />
                </ProtectedRoute>
              }
            />
            <Route
              path="users/new"
              element={
                <ProtectedRoute roles={['admin']}>
                  <UserForm />
                </ProtectedRoute>
              }
            />
            <Route
              path="users/:id/edit"
              element={
                <ProtectedRoute roles={['admin']}>
                  <UserForm />
                </ProtectedRoute>
              }
            />
          </Route>

          {/* Rota 404 */}
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>

        {/* Toast notifications */}
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: 'hsl(var(--card))',
              color: 'hsl(var(--card-foreground))',
              border: '1px solid hsl(var(--border))',
            },
          }}
        />
      </div>
    </Router>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;

